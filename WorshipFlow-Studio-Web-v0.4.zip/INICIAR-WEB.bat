@echo off
title WorshipFlow Studio Web
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao foi encontrado.
  echo Instale o Node.js e abra este arquivo novamente.
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo Preparando o WorshipFlow pela primeira vez...
  call npm install
  if errorlevel 1 (
    echo Nao foi possivel instalar os componentes.
    pause
    exit /b 1
  )
)

echo Iniciando WorshipFlow Studio Web...
echo Para encerrar, feche esta janela ou pressione Ctrl+C.
call npm run web
pause
