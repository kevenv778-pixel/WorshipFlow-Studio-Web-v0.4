# WorshipFlow 0.4

Central profissional de exibição e produção audiovisual com duas formas de uso:

- **Studio Web Local:** funciona no navegador, sem instalação do Electron.
- **Desktop:** mantém o painel clássico de letras, roteiro e segunda tela.

## Iniciar a versão web local no Windows

Extraia a pasta e dê dois cliques em **`INICIAR-WEB.bat`**. O painel abrirá automaticamente no endereço `http://localhost:5173`.

Na primeira execução, permita o acesso à câmera, microfone ou compartilhamento de tela somente quando usar essas fontes. Os arquivos importados e as cenas ficam armazenados localmente no navegador.

Também é possível iniciar pelo terminal:

```bash
npm install
npm run web
```

Para permitir que outro aparelho da mesma rede abra o painel:

```bash
npm run web:lan
```

## Studio Web implementado

- Cenas independentes com duplicação, exclusão e ordem de exibição.
- Preview separado do programa que está ao vivo.
- Fontes simultâneas em camadas: câmera, captura de tela, vídeo, áudio, imagem, PDF, YouTube, letras e textos.
- Composições em tela cheia, central, picture-in-picture e rodapé.
- Visibilidade, volume e silenciamento independentes por fonte.
- Transições por corte, fade, dissolução e deslizamento.
- Blackout instantâneo.
- Janela limpa para telão, projetor ou captura no OBS.
- Biblioteca de mídia persistente no navegador por IndexedDB.
- Programação visual das cenas do evento.
- Gravação local da janela de saída em WebM.
- Operação local e offline, exceto conteúdos online como YouTube.

## Nova interface 0.4

- Mesa de produção com **Prévia** e **Programa** lado a lado.
- Identificação visual `PVW` e `PGM` nas cenas.
- Estado **NO AR**, blackout e integridade do sistema visíveis o tempo todo.
- Transição, duração, cena anterior e próxima no mesmo painel de operação.
- Horário e programação atual no cabeçalho.
- Controles de fontes mais claros, com estado ativa/oculta e volume individual.
- Biblioteca com pesquisa, filtros e contadores por tipo de mídia.
- Programação com resumo de cenas, fontes, mídias e indicação da cena no ar.

### Transmissão ao vivo

A saída limpa pode ser adicionada ao OBS como fonte de navegador ou captura de janela. A transmissão direta por RTMP será a próxima etapa, pois exige um processo local de codificação (por exemplo, FFmpeg) e a chave de transmissão da plataforma.

## Desktop implementado

- Interface profissional em três áreas: biblioteca, pré-visualização e roteiro.
- Biblioteca local de louvores, vídeos e imagens.
- Inclusão de vídeos do YouTube por link, com reconhecimento de links comuns, youtu.be, Shorts e lives.
- Cadastro de letras divididas automaticamente em verso, refrão, ponte e outras partes.
- Roteiro do culto persistido em SQLite e reorganizável por arrastar e soltar.
- Janela independente e em tela cheia para projetor ou segundo monitor.
- Conteúdo preparado separado do conteúdo atualmente exibido.
- Controles Anterior, Exibir e Próximo.
- Blackout, tela limpa e relógio.
- Atalhos F1 a F6 e ESC.
- Detecção e memorização da tela escolhida.
- Dados e mídias locais: o culto continua sem internet.

## Vídeos do YouTube

Abra a aba **Mídia**, clique em **Adicionar link do YouTube**, cole o endereço e adicione à biblioteca. O título é buscado automaticamente quando possível. Vídeos do YouTube exigem internet e permanecem sujeitos à disponibilidade e às regras da plataforma; conteúdos essenciais ao culto devem ter uma alternativa local autorizada.

## Executar a versão desktop em desenvolvimento

Requisitos: Node.js 22 ou mais recente.

```bash
npm install
npm run dev
```

## Validar a compilação

```bash
npm run typecheck
npm run build
```

## Atalhos

| Tecla | Ação |
| --- | --- |
| F1 | Ativar/desativar blackout |
| F2 | Próxima parte ou próximo item |
| F3 | Parte ou item anterior |
| F4 | Pausar vídeo |
| F5 | Tela limpa |
| F6 | Mostrar relógio |
| ESC | Fechar a janela de apresentação |

## Estrutura

- `electron/`: janelas, telas, atalhos, importação de mídia e banco SQLite.
- `src/`: interface React, controles e motor de apresentação.
- `src/domain/presenter.ts`: transformação dos itens do roteiro em conteúdo para o telão.

O banco `worshipflow.db` é criado automaticamente na pasta de dados do aplicativo. A primeira inicialização inclui três louvores demonstrativos e um roteiro de culto para facilitar os testes.
