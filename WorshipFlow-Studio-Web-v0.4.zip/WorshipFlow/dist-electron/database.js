import { app } from 'electron';
import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
const songSeed = [
    {
        title: 'Cântico de Celebração',
        artist: 'Exemplo WorshipFlow',
        musicalKey: 'G',
        category: 'Celebração',
        segments: [
            { label: 'VERSO 1', text: 'Hoje celebramos com alegria\nA esperança que nos faz caminhar' },
            { label: 'REFRÃO', text: 'Cantaremos juntos com gratidão\nTua graça nos conduz' },
            { label: 'VERSO 2', text: 'Cada novo dia anuncia\nTeu cuidado sobre nós' },
            { label: 'REFRÃO', text: 'Cantaremos juntos com gratidão\nTua graça nos conduz' },
        ],
    },
    {
        title: 'Graça e Bondade',
        artist: 'Exemplo WorshipFlow',
        musicalKey: 'A',
        category: 'Adoração',
        segments: [
            { label: 'VERSO', text: 'Em Tua presença encontramos paz\nNossos corações se rendem a Ti' },
            { label: 'REFRÃO', text: 'Tua graça e bondade permanecerão\nPara sempre cantaremos' },
            { label: 'PONTE', text: 'Em cada passo, em cada manhã\nTua mão nos guiará' },
            { label: 'REFRÃO', text: 'Tua graça e bondade permanecerão\nPara sempre cantaremos' },
        ],
    },
    {
        title: 'Santo é o Senhor',
        artist: 'Exemplo WorshipFlow',
        musicalKey: 'D',
        category: 'Adoração',
        segments: [
            { label: 'VERSO', text: 'Toda a criação revela Tua glória\nCéus e terra cantam Teu louvor' },
            { label: 'REFRÃO', text: 'Santo é o Senhor, digno de adoração\nPara sempre reinarás' },
        ],
    },
];
export class WorshipDatabase {
    db;
    constructor() {
        const databasePath = path.join(app.getPath('userData'), 'worshipflow.db');
        this.db = new DatabaseSync(databasePath);
        this.db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;');
        this.migrate();
        this.seed();
    }
    migrate() {
        this.db.exec(`
      CREATE TABLE IF NOT EXISTS songs (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        artist TEXT NOT NULL DEFAULT '',
        musical_key TEXT NOT NULL DEFAULT '',
        category TEXT NOT NULL DEFAULT 'Geral',
        lyrics_json TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE TABLE IF NOT EXISTS media (
        id TEXT PRIMARY KEY,
        kind TEXT NOT NULL CHECK(kind IN ('video', 'image')),
        title TEXT NOT NULL,
        file_path TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Geral',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE TABLE IF NOT EXISTS services (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        service_date TEXT NOT NULL,
        start_time TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE TABLE IF NOT EXISTS service_items (
        id TEXT PRIMARY KEY,
        service_id TEXT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
        item_type TEXT NOT NULL,
        content_id TEXT,
        title TEXT NOT NULL,
        position INTEGER NOT NULL,
        payload_json TEXT NOT NULL DEFAULT '{}'
      );
      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      );
    `);
    }
    seed() {
        const total = this.db.prepare('SELECT COUNT(*) AS count FROM songs').get();
        if (total.count === 0) {
            const insert = this.db.prepare(`
        INSERT INTO songs (id, title, artist, musical_key, category, lyrics_json)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
            for (const song of songSeed) {
                insert.run(randomUUID(), song.title, song.artist, song.musicalKey, song.category, JSON.stringify(song.segments));
            }
        }
        const services = this.db.prepare('SELECT COUNT(*) AS count FROM services').get();
        if (services.count === 0) {
            const serviceId = randomUUID();
            const today = new Date().toISOString().slice(0, 10);
            this.db.prepare('INSERT INTO services (id, title, service_date, start_time) VALUES (?, ?, ?, ?)')
                .run(serviceId, 'Culto de Domingo', today, '19:00');
            const songs = this.db.prepare('SELECT id, title FROM songs ORDER BY created_at LIMIT 3').all();
            const insertItem = this.db.prepare(`
        INSERT INTO service_items (id, service_id, item_type, content_id, title, position, payload_json)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
            insertItem.run(randomUUID(), serviceId, 'notice', null, 'Boas-vindas', 0, JSON.stringify({ text: 'Sejam todos bem-vindos' }));
            songs.forEach((song, index) => {
                insertItem.run(randomUUID(), serviceId, 'song', song.id, song.title, index + 1, '{}');
            });
            insertItem.run(randomUUID(), serviceId, 'bible', null, 'João 3:16', 4, JSON.stringify({
                reference: 'João 3:16',
                text: 'Porque Deus amou o mundo de tal maneira que deu o seu Filho unigênito.'
            }));
        }
    }
    listLibrary() {
        const songs = this.db.prepare('SELECT * FROM songs ORDER BY title COLLATE NOCASE').all().map((row) => {
            const item = row;
            return {
                id: item.id,
                title: item.title,
                artist: item.artist,
                musicalKey: item.musical_key,
                category: item.category,
                segments: JSON.parse(item.lyrics_json),
            };
        });
        const media = this.db.prepare('SELECT * FROM media ORDER BY title COLLATE NOCASE').all().map((row) => {
            const item = row;
            return {
                id: item.id,
                kind: item.kind,
                title: item.title,
                path: item.file_path,
                category: item.category,
                source: item.category === 'YouTube' ? 'youtube' : 'local',
                videoId: item.category === 'YouTube' ? extractYoutubeVideoId(item.file_path) ?? undefined : undefined,
            };
        });
        return { songs, media };
    }
    createSong(song) {
        const id = randomUUID();
        this.db.prepare(`
      INSERT INTO songs (id, title, artist, musical_key, category, lyrics_json)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, song.title, song.artist, song.musicalKey, song.category, JSON.stringify(song.segments));
        return { id, ...song };
    }
    addMedia(input) {
        const id = randomUUID();
        this.db.prepare('INSERT INTO media (id, kind, title, file_path, category) VALUES (?, ?, ?, ?, ?)')
            .run(id, input.kind, input.title, input.path, input.category);
        return { id, source: input.source ?? 'local', ...input };
    }
    getActiveService() {
        const row = this.db.prepare('SELECT * FROM services ORDER BY created_at DESC LIMIT 1').get();
        const items = this.db.prepare('SELECT * FROM service_items WHERE service_id = ? ORDER BY position').all(row.id).map((entry) => {
            const item = entry;
            return {
                id: item.id,
                type: item.item_type,
                contentId: item.content_id,
                title: item.title,
                position: item.position,
                payload: JSON.parse(item.payload_json),
            };
        });
        return {
            id: row.id,
            title: row.title,
            serviceDate: row.service_date,
            startTime: row.start_time,
            items,
        };
    }
    replaceServiceItems(serviceId, items) {
        this.db.exec('BEGIN IMMEDIATE');
        try {
            this.db.prepare('DELETE FROM service_items WHERE service_id = ?').run(serviceId);
            const insert = this.db.prepare(`
        INSERT INTO service_items (id, service_id, item_type, content_id, title, position, payload_json)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
            items.forEach((item, position) => {
                insert.run(item.id || randomUUID(), serviceId, item.type, item.contentId, item.title, position, JSON.stringify(item.payload ?? {}));
            });
            this.db.exec('COMMIT');
        }
        catch (error) {
            this.db.exec('ROLLBACK');
            throw error;
        }
        return this.getActiveService();
    }
    getSetting(key) {
        const row = this.db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
        return row?.value ?? null;
    }
    setSetting(key, value) {
        this.db.prepare(`
      INSERT INTO settings (key, value) VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `).run(key, value);
    }
}
function extractYoutubeVideoId(value) {
    try {
        const url = new URL(value);
        const host = url.hostname.replace(/^www\./, '').toLowerCase();
        if (host === 'youtu.be')
            return url.pathname.split('/').filter(Boolean)[0] ?? null;
        if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com') {
            if (url.pathname === '/watch')
                return url.searchParams.get('v');
            const parts = url.pathname.split('/').filter(Boolean);
            if (['embed', 'shorts', 'live'].includes(parts[0]))
                return parts[1] ?? null;
        }
    }
    catch {
        return null;
    }
    return null;
}
//# sourceMappingURL=database.js.map