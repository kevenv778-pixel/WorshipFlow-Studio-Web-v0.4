import { contextBridge, ipcRenderer } from 'electron';
contextBridge.exposeInMainWorld('worshipFlow', {
    library: {
        list: () => ipcRenderer.invoke('library:list'),
        createSong: (song) => ipcRenderer.invoke('songs:create', song),
        importMedia: () => ipcRenderer.invoke('media:import'),
        addYoutube: (input) => ipcRenderer.invoke('media:add-youtube', input),
    },
    service: {
        getActive: () => ipcRenderer.invoke('service:get-active'),
        saveItems: (serviceId, items) => ipcRenderer.invoke('service:save-items', serviceId, items),
    },
    displays: {
        list: () => ipcRenderer.invoke('displays:list'),
        select: (displayId) => ipcRenderer.invoke('displays:select', displayId),
        onChanged: (callback) => {
            const listener = (_event, displays) => callback(displays);
            ipcRenderer.on('displays:changed', listener);
            return () => ipcRenderer.removeListener('displays:changed', listener);
        },
    },
    presenter: {
        show: () => ipcRenderer.invoke('presenter:show'),
        hide: () => ipcRenderer.invoke('presenter:hide'),
        update: (state) => ipcRenderer.send('presenter:update', state),
        getInitial: () => ipcRenderer.invoke('presenter:get-initial'),
        onState: (callback) => {
            const listener = (_event, state) => callback(state);
            ipcRenderer.on('presenter:state', listener);
            return () => ipcRenderer.removeListener('presenter:state', listener);
        },
        onCommand: (callback) => {
            const listener = (_event, command) => callback(command);
            ipcRenderer.on('presenter:command', listener);
            return () => ipcRenderer.removeListener('presenter:command', listener);
        },
    },
});
//# sourceMappingURL=preload.js.map