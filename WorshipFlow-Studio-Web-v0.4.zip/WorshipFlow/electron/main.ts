import { app, BrowserWindow, dialog, globalShortcut, ipcMain, net, protocol, screen } from 'electron';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { randomUUID } from 'node:crypto';
import { WorshipDatabase, type MediaRow, type ServiceItemRow, type SongRow } from './database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isDevelopment = !app.isPackaged;
let operatorWindow: BrowserWindow | null = null;
let projectorWindow: BrowserWindow | null = null;
let database: WorshipDatabase;
let presenterState: unknown = { mode: 'blackout' };

protocol.registerSchemesAsPrivileged([
  { scheme: 'wfmedia', privileges: { secure: true, supportFetchAPI: true, stream: true } },
]);

function rendererTarget(view?: string) {
  if (isDevelopment) return `http://localhost:5173${view ? `?view=${view}` : ''}`;
  const target = path.join(__dirname, '../dist/index.html');
  return view ? `${pathToFileURL(target).href}?view=${view}` : pathToFileURL(target).href;
}

function createOperatorWindow() {
  operatorWindow = new BrowserWindow({
    width: 1540,
    height: 940,
    minWidth: 1180,
    minHeight: 720,
    backgroundColor: '#08101d',
    title: 'WorshipFlow',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });
  void operatorWindow.loadURL(rendererTarget());
  operatorWindow.on('closed', () => { operatorWindow = null; });
}

function createProjectorWindow() {
  projectorWindow = new BrowserWindow({
    width: 1280,
    height: 720,
    show: false,
    frame: false,
    fullscreenable: true,
    skipTaskbar: true,
    backgroundColor: '#000000',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });
  void projectorWindow.loadURL(rendererTarget('projector'));
  projectorWindow.on('closed', () => { projectorWindow = null; });
}

function displayPayload() {
  const selected = database.getSetting('projectorDisplayId');
  return screen.getAllDisplays().map((display, index) => ({
    id: String(display.id),
    label: display.internal ? `Monitor principal` : `Tela externa ${index + 1}`,
    size: `${display.bounds.width} × ${display.bounds.height}`,
    primary: display.id === screen.getPrimaryDisplay().id,
    selected: selected ? String(display.id) === selected : !display.internal,
  }));
}

function targetDisplay() {
  const all = screen.getAllDisplays();
  const selected = database.getSetting('projectorDisplayId');
  return all.find((display) => String(display.id) === selected)
    ?? all.find((display) => !display.internal)
    ?? all[0];
}

function showProjector() {
  if (!projectorWindow || projectorWindow.isDestroyed()) createProjectorWindow();
  const display = targetDisplay();
  projectorWindow!.setBounds(display.bounds);
  projectorWindow!.setFullScreen(true);
  projectorWindow!.showInactive();
  projectorWindow!.webContents.send('presenter:state', presenterState);
  return { visible: true, displayId: String(display.id), external: !display.internal };
}

function registerIpc() {
  ipcMain.handle('library:list', () => database.listLibrary());
  ipcMain.handle('songs:create', (_event, song: Omit<SongRow, 'id'>) => database.createSong(song));
  ipcMain.handle('service:get-active', () => database.getActiveService());
  ipcMain.handle('service:save-items', (_event, serviceId: string, items: ServiceItemRow[]) => database.replaceServiceItems(serviceId, items));
  ipcMain.handle('displays:list', () => displayPayload());
  ipcMain.handle('displays:select', (_event, displayId: string) => {
    database.setSetting('projectorDisplayId', displayId);
    operatorWindow?.webContents.send('displays:changed', displayPayload());
    return displayPayload();
  });
  ipcMain.handle('media:import', async () => {
    const result = await dialog.showOpenDialog(operatorWindow!, {
      title: 'Adicionar mídia à biblioteca',
      properties: ['openFile', 'multiSelections'],
      filters: [
        { name: 'Vídeos e imagens', extensions: ['mp4', 'webm', 'mov', 'm4v', 'jpg', 'jpeg', 'png', 'webp'] },
        { name: 'Todos os arquivos', extensions: ['*'] },
      ],
    });
    if (result.canceled) return [];
    return result.filePaths.map((filePath) => {
      const extension = path.extname(filePath).toLowerCase();
      const kind: MediaRow['kind'] = ['.jpg', '.jpeg', '.png', '.webp'].includes(extension) ? 'image' : 'video';
      return database.addMedia({
        kind,
        path: filePath,
        title: path.basename(filePath, extension),
        category: kind === 'video' ? 'Vídeos' : 'Imagens',
        source: 'local',
      });
    });
  });
  ipcMain.handle('media:add-youtube', async (_event, input: { url: string; videoId: string; title?: string }) => {
    const url = input.url.trim();
    const videoId = input.videoId.trim();
    if (!/^[A-Za-z0-9_-]{11}$/.test(videoId)) throw new Error('Link do YouTube inválido.');

    let title = input.title?.trim() || '';
    if (!title) {
      try {
        const response = await net.fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`);
        if (response.ok) {
          const metadata = await response.json() as { title?: string };
          title = metadata.title?.trim() || '';
        }
      } catch {
        // O vídeo ainda pode ser salvo quando os metadados não estiverem disponíveis.
      }
    }

    return database.addMedia({
      kind: 'video',
      title: title || `Vídeo do YouTube (${videoId})`,
      path: url,
      category: 'YouTube',
      source: 'youtube',
      videoId,
    });
  });
  ipcMain.handle('presenter:show', () => showProjector());
  ipcMain.handle('presenter:hide', () => {
    projectorWindow?.hide();
    return { visible: false };
  });
  ipcMain.handle('presenter:get-initial', () => presenterState);
  ipcMain.on('presenter:update', (_event, state) => {
    presenterState = state;
    projectorWindow?.webContents.send('presenter:state', state);
  });
}

function registerShortcuts() {
  const commands: Record<string, string> = {
    F1: 'blackout',
    F2: 'next',
    F3: 'previous',
    F4: 'pause',
    F5: 'clear',
    F6: 'clock',
  };
  Object.entries(commands).forEach(([key, command]) => {
    globalShortcut.register(key, () => operatorWindow?.webContents.send('presenter:command', command));
  });
}

app.whenReady().then(() => {
  database = new WorshipDatabase();
  protocol.handle('wfmedia', (request) => {
    const encoded = new URL(request.url).pathname.slice(1);
    const filePath = Buffer.from(encoded, 'base64url').toString('utf8');
    return net.fetch(pathToFileURL(filePath).href);
  });
  registerIpc();
  createOperatorWindow();
  createProjectorWindow();
  registerShortcuts();

  screen.on('display-added', () => operatorWindow?.webContents.send('displays:changed', displayPayload()));
  screen.on('display-removed', () => operatorWindow?.webContents.send('displays:changed', displayPayload()));
  screen.on('display-metrics-changed', () => operatorWindow?.webContents.send('displays:changed', displayPayload()));
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createOperatorWindow();
      createProjectorWindow();
    }
  });
});

app.on('will-quit', () => globalShortcut.unregisterAll());
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
