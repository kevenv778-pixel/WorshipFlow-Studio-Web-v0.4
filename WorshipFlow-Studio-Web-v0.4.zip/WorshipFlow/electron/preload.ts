import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('worshipFlow', {
  library: {
    list: () => ipcRenderer.invoke('library:list'),
    createSong: (song: unknown) => ipcRenderer.invoke('songs:create', song),
    importMedia: () => ipcRenderer.invoke('media:import'),
    addYoutube: (input: unknown) => ipcRenderer.invoke('media:add-youtube', input),
  },
  service: {
    getActive: () => ipcRenderer.invoke('service:get-active'),
    saveItems: (serviceId: string, items: unknown[]) => ipcRenderer.invoke('service:save-items', serviceId, items),
  },
  displays: {
    list: () => ipcRenderer.invoke('displays:list'),
    select: (displayId: string) => ipcRenderer.invoke('displays:select', displayId),
    onChanged: (callback: (displays: unknown[]) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, displays: unknown[]) => callback(displays);
      ipcRenderer.on('displays:changed', listener);
      return () => ipcRenderer.removeListener('displays:changed', listener);
    },
  },
  presenter: {
    show: () => ipcRenderer.invoke('presenter:show'),
    hide: () => ipcRenderer.invoke('presenter:hide'),
    update: (state: unknown) => ipcRenderer.send('presenter:update', state),
    getInitial: () => ipcRenderer.invoke('presenter:get-initial'),
    onState: (callback: (state: unknown) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, state: unknown) => callback(state);
      ipcRenderer.on('presenter:state', listener);
      return () => ipcRenderer.removeListener('presenter:state', listener);
    },
    onCommand: (callback: (command: string) => void) => {
      const listener = (_event: Electron.IpcRendererEvent, command: string) => callback(command);
      ipcRenderer.on('presenter:command', listener);
      return () => ipcRenderer.removeListener('presenter:command', listener);
    },
  },
});
