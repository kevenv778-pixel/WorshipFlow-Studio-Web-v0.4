import { useCallback, useEffect, useMemo, useState } from 'react';
import { Icon } from './components/Icons';
import { PresentationCanvas } from './components/PresentationCanvas';
import { SongModal } from './components/SongModal';
import { YoutubeModal } from './components/YoutubeModal';
import { resolvePresentation, slideCount } from './domain/presenter';
import type { DisplayInfo, ItemType, MediaItem, PresentationMode, PresentationState, Service, ServiceItem, Song } from './types';

const typeMeta: Record<ItemType, { label: string; icon: string; color: string }> = {
  song: { label: 'Louvor', icon: 'music', color: 'violet' },
  video: { label: 'Vídeo', icon: 'video', color: 'rose' },
  image: { label: 'Imagem', icon: 'image', color: 'amber' },
  bible: { label: 'Bíblia', icon: 'bible', color: 'blue' },
  notice: { label: 'Aviso', icon: 'slides', color: 'teal' },
};

function newId() {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;
}

export function App() {
  const [songs, setSongs] = useState<Song[]>([]);
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [service, setService] = useState<Service | null>(null);
  const [displays, setDisplays] = useState<DisplayInfo[]>([]);
  const [query, setQuery] = useState('');
  const [libraryTab, setLibraryTab] = useState<'songs' | 'media'>('songs');
  const [previewIndex, setPreviewIndex] = useState(0);
  const [liveIndex, setLiveIndex] = useState<number | null>(null);
  const [liveSlide, setLiveSlide] = useState(0);
  const [mode, setMode] = useState<PresentationMode>('clear');
  const [videoPaused, setVideoPaused] = useState(false);
  const [projectorVisible, setProjectorVisible] = useState(false);
  const [showSongModal, setShowSongModal] = useState(false);
  const [showYoutubeModal, setShowYoutubeModal] = useState(false);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [toast, setToast] = useState('');

  const refreshLibrary = useCallback(async () => {
    const data = await window.worshipFlow.library.list();
    setSongs(data.songs);
    setMedia(data.media);
  }, []);

  useEffect(() => {
    void Promise.all([
      refreshLibrary(),
      window.worshipFlow.service.getActive().then(setService),
      window.worshipFlow.displays.list().then(setDisplays),
    ]);
    const stopDisplays = window.worshipFlow.displays.onChanged(setDisplays);
    return stopDisplays;
  }, [refreshLibrary]);

  const items = service?.items ?? [];
  const previewItem = items[previewIndex];
  const liveItem = liveIndex === null ? undefined : items[liveIndex];
  const basePreview = resolvePresentation(previewItem, previewIndex === liveIndex ? liveSlide : 0, songs, media);
  const liveState: PresentationState = mode === 'content'
    ? { ...resolvePresentation(liveItem, liveSlide, songs, media), paused: videoPaused }
    : { mode, theme: 'midnight' };

  useEffect(() => {
    window.worshipFlow.presenter.update(liveState);
  }, [liveState.mode, liveState.type, liveState.title, liveState.text, liveState.mediaUrl, liveState.youtubeId, liveState.paused]);

  const showPreview = useCallback(async () => {
    if (!items[previewIndex]) return;
    setLiveIndex(previewIndex);
    setLiveSlide(0);
    setVideoPaused(false);
    setMode('content');
    const result = await window.worshipFlow.presenter.show();
    setProjectorVisible(result.visible);
    setToast(result.external ? 'Conteúdo enviado ao projetor' : 'Apresentação aberta no monitor principal');
  }, [items, previewIndex]);

  const next = useCallback(() => {
    if (!items.length) return;
    if (liveIndex === null) {
      setLiveIndex(previewIndex);
      setLiveSlide(0);
      setMode('content');
      return;
    }
    const count = slideCount(items[liveIndex], songs);
    if (liveSlide < count - 1) {
      setLiveSlide((value) => value + 1);
      setVideoPaused(false);
      return;
    }
    const nextIndex = Math.min(liveIndex + 1, items.length - 1);
    setLiveIndex(nextIndex);
    setPreviewIndex(nextIndex);
    setLiveSlide(0);
    setVideoPaused(false);
    setMode('content');
  }, [items, liveIndex, liveSlide, previewIndex, songs]);

  const previous = useCallback(() => {
    if (liveIndex === null) return;
    if (liveSlide > 0) {
      setLiveSlide((value) => value - 1);
      setVideoPaused(false);
      return;
    }
    const previousIndex = Math.max(0, liveIndex - 1);
    setLiveIndex(previousIndex);
    setPreviewIndex(previousIndex);
    setLiveSlide(Math.max(0, slideCount(items[previousIndex], songs) - 1));
    setVideoPaused(false);
    setMode('content');
  }, [items, liveIndex, liveSlide, songs]);

  const command = useCallback((name: string) => {
    if (name === 'next') next();
    if (name === 'previous') previous();
    if (name === 'blackout') setMode((value) => value === 'blackout' ? 'content' : 'blackout');
    if (name === 'clear') setMode('clear');
    if (name === 'clock') setMode('clock');
    if (name === 'pause') {
      if (liveItem?.type !== 'video') setToast('Nenhum vídeo está no telão');
      else setVideoPaused((value) => {
        setToast(value ? 'Vídeo retomado' : 'Vídeo pausado');
        return !value;
      });
    }
  }, [liveItem?.type, next, previous]);

  useEffect(() => window.worshipFlow.presenter.onCommand(command), [command]);
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const map: Record<string, string> = { F1: 'blackout', F2: 'next', F3: 'previous', F4: 'pause', F5: 'clear', F6: 'clock' };
      if (map[event.key]) { event.preventDefault(); command(map[event.key]); }
      if (event.key === 'Escape') void window.worshipFlow.presenter.hide().then(() => setProjectorVisible(false));
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [command]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 2800);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const filteredSongs = useMemo(() => songs.filter((song) => `${song.title} ${song.artist} ${song.category}`.toLowerCase().includes(query.toLowerCase())), [songs, query]);
  const filteredMedia = useMemo(() => media.filter((asset) => asset.title.toLowerCase().includes(query.toLowerCase())), [media, query]);

  async function saveItems(nextItems: ServiceItem[]) {
    if (!service) return;
    const saved = await window.worshipFlow.service.saveItems(service.id, nextItems.map((item, position) => ({ ...item, position })));
    setService(saved);
  }

  function addLibraryItem(type: 'song' | 'video' | 'image', item: Song | MediaItem) {
    const next: ServiceItem = { id: newId(), type, contentId: item.id, title: item.title, position: items.length, payload: {} };
    void saveItems([...items, next]);
    setToast(`${item.title} adicionado ao roteiro`);
  }

  async function importMedia() {
    const imported = await window.worshipFlow.library.importMedia();
    if (imported.length) {
      await refreshLibrary();
      setLibraryTab('media');
      setToast(`${imported.length} ${imported.length === 1 ? 'arquivo importado' : 'arquivos importados'}`);
    }
  }

  async function reorder(dropIndex: number) {
    if (dragIndex === null || dragIndex === dropIndex) return;
    const nextItems = [...items];
    const [moved] = nextItems.splice(dragIndex, 1);
    nextItems.splice(dropIndex, 0, moved);
    setDragIndex(null);
    await saveItems(nextItems);
  }

  const selectedDisplay = displays.find((display) => display.selected) ?? displays.find((display) => !display.primary) ?? displays[0];
  const upcoming = liveIndex === null ? items[0] : items[liveIndex + 1];

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><span /><span /><span /></div>
          <div><strong>Worship<span>Flow</span></strong><small>Apresentação para igrejas</small></div>
        </div>
        <div className="service-title">
          <span className="eyebrow">PROGRAMAÇÃO ATUAL</span>
          <strong>{service?.title ?? 'Carregando...'}</strong>
          <small>{service ? `${new Date(`${service.serviceDate}T12:00:00`).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })} • ${service.startTime}` : ''}</small>
        </div>
        <div className="projector-status">
          <div className={`status-dot ${projectorVisible ? 'online' : ''}`} />
          <div><strong>{displays.length > 1 ? 'Projetor encontrado' : 'Uma tela detectada'}</strong><small>{selectedDisplay?.size ?? 'Detectando...'}</small></div>
          <select aria-label="Selecionar tela" value={selectedDisplay?.id ?? ''} onChange={(event) => void window.worshipFlow.displays.select(event.target.value).then(setDisplays)}>
            {displays.map((display) => <option key={display.id} value={display.id}>{display.label}</option>)}
          </select>
          <button className="button compact" onClick={() => void showPreview()}><Icon name="display" />{projectorVisible ? 'Em exibição' : 'Iniciar'}</button>
        </div>
      </header>

      <div className="workspace">
        <aside className="library-panel">
          <div className="panel-heading"><div><span className="eyebrow">CONTEÚDO</span><h2>Biblioteca</h2></div><button className="icon-button" onClick={() => setShowSongModal(true)} title="Novo louvor"><Icon name="plus" /></button></div>
          <div className="search-box"><Icon name="search" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar na biblioteca" /></div>
          <div className="library-tabs">
            <button className={libraryTab === 'songs' ? 'active' : ''} onClick={() => setLibraryTab('songs')}><Icon name="music" />Louvores <span>{songs.length}</span></button>
            <button className={libraryTab === 'media' ? 'active' : ''} onClick={() => setLibraryTab('media')}><Icon name="video" />Mídia <span>{media.length}</span></button>
          </div>
          <div className="library-list">
            {libraryTab === 'songs' && filteredSongs.map((song) => (
              <button key={song.id} className="library-card" onClick={() => addLibraryItem('song', song)}>
                <div className="item-icon violet"><Icon name="music" /></div>
                <div className="library-copy"><strong>{song.title}</strong><span>{song.artist || 'Sem artista'} • {song.category}</span><small>{song.segments.length} partes {song.musicalKey && `• Tom ${song.musicalKey}`}</small></div>
                <div className="add-badge"><Icon name="plus" /></div>
              </button>
            ))}
            {libraryTab === 'media' && filteredMedia.map((asset) => (
              <button key={asset.id} className="library-card" onClick={() => addLibraryItem(asset.kind, asset)}>
                <div className={`item-icon ${asset.source === 'youtube' ? 'youtube' : asset.kind === 'video' ? 'rose' : 'amber'}`}><Icon name={asset.source === 'youtube' ? 'youtube' : asset.kind} /></div>
                <div className="library-copy"><strong>{asset.title}</strong><span>{asset.source === 'youtube' ? 'YouTube • requer internet' : asset.kind === 'video' ? 'Vídeo local' : 'Imagem local'}</span><small>{asset.category}</small></div>
                <div className="add-badge"><Icon name="plus" /></div>
              </button>
            ))}
            {libraryTab === 'media' && !filteredMedia.length && <div className="empty-library"><Icon name="video" /><strong>Sua mídia local</strong><p>Adicione vídeos e imagens para usar mesmo sem internet.</p></div>}
          </div>
          <div className="library-footer">
            <button className="button full youtube-link-button" onClick={() => setShowYoutubeModal(true)}><Icon name="youtube" />Adicionar link do YouTube</button>
            <button className="button full ghost" onClick={() => void importMedia()}><Icon name="plus" />Importar mídia local</button>
          </div>
        </aside>

        <main className="preview-panel">
          <div className="preview-heading">
            <div><span className="eyebrow">PREPARAÇÃO</span><h2>Pré-visualização</h2></div>
            <div className="preview-tag"><span /> PRONTO PARA EXIBIR</div>
          </div>
          <div className="preview-stage"><PresentationCanvas state={basePreview} preview /></div>
          <div className="preview-details">
            <div className={`item-icon ${previewItem ? typeMeta[previewItem.type].color : 'violet'}`}><Icon name={previewItem ? typeMeta[previewItem.type].icon : 'slides'} /></div>
            <div><span className="eyebrow">SELECIONADO</span><h3>{previewItem?.title ?? 'Nenhum item selecionado'}</h3><p>{previewItem ? typeMeta[previewItem.type].label : 'Escolha um item no roteiro'}</p></div>
            {previewItem?.type === 'song' && <div className="slide-pills">{songs.find((song) => song.id === previewItem.contentId)?.segments.map((segment, index) => <span key={`${segment.label}-${index}`} className={previewIndex === liveIndex && liveSlide === index ? 'active' : ''}>{index + 1}</span>)}</div>}
          </div>
          <div className="now-next">
            <div className="now-card"><span className="live-pill">● NO TELÃO</span><strong>{liveItem?.title ?? 'Tela limpa'}</strong><small>{liveItem ? typeMeta[liveItem.type].label : 'Nenhum conteúdo ativo'}</small></div>
            <Icon name="chevronRight" />
            <div className="next-card"><span className="eyebrow">A SEGUIR</span><strong>{upcoming?.title ?? 'Fim da programação'}</strong><small>{upcoming ? typeMeta[upcoming.type].label : '—'}</small></div>
          </div>
        </main>

        <aside className="rundown-panel">
          <div className="panel-heading"><div><span className="eyebrow">ORDEM DO CULTO</span><h2>Próximos</h2></div><span className="item-count">{items.length} itens</span></div>
          <div className="rundown-list">
            {items.map((item, index) => {
              const meta = typeMeta[item.type];
              const isLive = index === liveIndex && mode === 'content';
              return (
                <div key={item.id} draggable onDragStart={() => setDragIndex(index)} onDragOver={(event) => event.preventDefault()} onDrop={() => void reorder(index)} onClick={() => setPreviewIndex(index)} className={`rundown-item ${index === previewIndex ? 'selected' : ''} ${isLive ? 'live' : ''}`}>
                  <span className="drag-handle"><Icon name="grip" /></span><span className="rundown-number">{String(index + 1).padStart(2, '0')}</span>
                  <div className={`item-icon small ${meta.color}`}><Icon name={meta.icon} /></div>
                  <div className="rundown-copy"><strong>{item.title}</strong><span>{isLive ? 'NO TELÃO AGORA' : meta.label}</span></div>
                  {isLive && <span className="live-wave"><i /><i /><i /></span>}
                </div>
              );
            })}
          </div>
          <div className="rundown-help"><Icon name="grip" /><span>Arraste os itens para reorganizar o culto</span></div>
        </aside>
      </div>

      <footer className="controlbar">
        <div className="keyboard-hint"><strong>ATALHOS</strong><span><kbd>F1</kbd> Preto</span><span><kbd>F2</kbd> Próximo</span><span><kbd>F3</kbd> Anterior</span><span><kbd>F5</kbd> Limpar</span></div>
        <div className="main-controls">
          <button className="control-button" onClick={previous}><Icon name="chevronLeft" /><span>Anterior</span><kbd>F3</kbd></button>
          <button className="control-button show-button" onClick={() => void showPreview()}><Icon name="display" /><span>Exibir</span><small>NO TELÃO</small></button>
          <button className="control-button" onClick={next}><span>Próximo</span><Icon name="chevronRight" /><kbd>F2</kbd></button>
        </div>
        <div className="emergency-controls">
          <button className={mode === 'clear' ? 'active' : ''} onClick={() => setMode('clear')}><Icon name="clear" /><span>Tela limpa</span><kbd>F5</kbd></button>
          <button className={mode === 'clock' ? 'active' : ''} onClick={() => setMode('clock')}><Icon name="clock" /><span>Relógio</span><kbd>F6</kbd></button>
          <button className={`blackout-button ${mode === 'blackout' ? 'active' : ''}`} onClick={() => setMode(mode === 'blackout' ? 'content' : 'blackout')}><Icon name="blackout" /><span>Blackout</span><kbd>F1</kbd></button>
        </div>
      </footer>

      {showSongModal && <SongModal onClose={() => setShowSongModal(false)} onSave={async (song) => { await window.worshipFlow.library.createSong(song); await refreshLibrary(); setShowSongModal(false); setToast('Louvor salvo na biblioteca'); }} />}
      {showYoutubeModal && <YoutubeModal onClose={() => setShowYoutubeModal(false)} onSave={async (input) => { const item = await window.worshipFlow.library.addYoutube(input); await refreshLibrary(); setLibraryTab('media'); setShowYoutubeModal(false); setToast(`${item.title} adicionado à biblioteca`); return item; }} />}
      {toast && <div className="toast"><span>✓</span>{toast}</div>}
    </div>
  );
}
