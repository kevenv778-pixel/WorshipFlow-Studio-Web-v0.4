import { useEffect, useState } from 'react';
import { PresentationCanvas } from './components/PresentationCanvas';
import type { PresentationState } from './types';

export function ProjectorView() {
  const [state, setState] = useState<PresentationState>({ mode: 'blackout' });

  useEffect(() => {
    void window.worshipFlow.presenter.getInitial().then(setState);
    return window.worshipFlow.presenter.onState(setState);
  }, []);

  return <main className="projector-root"><PresentationCanvas state={state} /></main>;
}
