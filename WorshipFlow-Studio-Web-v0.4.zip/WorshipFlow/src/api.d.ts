import type { DisplayInfo, MediaItem, PresentationState, Service, ServiceItem, Song } from './types';

declare global {
  interface Window {
    worshipFlow: {
      library: {
        list: () => Promise<{ songs: Song[]; media: MediaItem[] }>;
        createSong: (song: Omit<Song, 'id'>) => Promise<Song>;
        importMedia: () => Promise<MediaItem[]>;
        addYoutube: (input: { url: string; videoId: string; title?: string }) => Promise<MediaItem>;
      };
      service: {
        getActive: () => Promise<Service>;
        saveItems: (serviceId: string, items: ServiceItem[]) => Promise<Service>;
      };
      displays: {
        list: () => Promise<DisplayInfo[]>;
        select: (displayId: string) => Promise<DisplayInfo[]>;
        onChanged: (callback: (displays: DisplayInfo[]) => void) => () => void;
      };
      presenter: {
        show: () => Promise<{ visible: boolean; displayId: string; external: boolean }>;
        hide: () => Promise<{ visible: boolean }>;
        update: (state: PresentationState) => void;
        getInitial: () => Promise<PresentationState>;
        onState: (callback: (state: PresentationState) => void) => () => void;
        onCommand: (callback: (command: string) => void) => () => void;
      };
    };
  }
}

export {};
