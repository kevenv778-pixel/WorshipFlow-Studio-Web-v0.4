import { useEffect, useRef, useState } from 'react';
import type { PresentationState } from '../types';

interface Props {
  state: PresentationState;
  preview?: boolean;
}

export function PresentationCanvas({ state, preview = false }: Props) {
  if (state.mode === 'blackout') return <div className="presentation-canvas blackout" />;
  if (state.mode === 'clear') return <div className="presentation-canvas clear-screen"><div className="ambient-orb" /></div>;
  if (state.mode === 'clock') return <ClockCanvas preview={preview} />;

  const className = `presentation-canvas theme-${state.theme ?? 'aurora'} type-${state.type ?? 'notice'}`;
  if (state.type === 'video' && state.youtubeId) {
    return <YoutubeCanvas className={className} state={state} preview={preview} />;
  }
  if (state.type === 'video' && state.mediaUrl) {
    return <VideoCanvas className={className} state={state} preview={preview} />;
  }
  if (state.type === 'image' && state.mediaUrl) {
    return <div className={className}><img src={state.mediaUrl} alt={state.title ?? ''} /></div>;
  }
  return (
    <div className={className}>
      <div className="ambient-orb" />
      <div className="canvas-grid" />
      <div className="canvas-content">
        {state.label && <div className="canvas-label">{state.label}</div>}
        {state.text && <div className="canvas-text">{state.text}</div>}
        {!state.text && state.title && <div className="canvas-text">{state.title}</div>}
        {(state.type === 'bible' || state.type === 'notice') && state.title && state.text && (
          <div className="canvas-reference">{state.title}</div>
        )}
      </div>
      {state.type === 'song' && (
        <div className="canvas-meta">
          <span>{state.title}</span>
          <span>{state.subtitle}</span>
        </div>
      )}
    </div>
  );
}

function VideoCanvas({ className, state, preview }: { className: string; state: PresentationState; preview: boolean }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    if (state.paused) ref.current.pause();
    else void ref.current.play().catch(() => undefined);
  }, [state.paused, state.mediaUrl]);
  return <div className={className}><video ref={ref} src={state.mediaUrl} autoPlay loop muted={preview} controls={preview} /></div>;
}

function YoutubeCanvas({ className, state, preview }: { className: string; state: PresentationState; preview: boolean }) {
  const ref = useRef<HTMLIFrameElement>(null);
  useEffect(() => {
    const command = state.paused ? 'pauseVideo' : 'playVideo';
    ref.current?.contentWindow?.postMessage(JSON.stringify({ event: 'command', func: command, args: [] }), 'https://www.youtube.com');
  }, [state.paused]);
  const params = new URLSearchParams({
    autoplay: preview ? '0' : '1',
    controls: '1',
    enablejsapi: '1',
    playsinline: '1',
    rel: '0',
  });
  if (window.location.origin.startsWith('http')) params.set('origin', window.location.origin);
  if (preview) params.set('mute', '1');
  return (
    <div className={`${className} youtube-canvas`}>
      <iframe
        ref={ref}
        src={`https://www.youtube.com/embed/${state.youtubeId}?${params.toString()}`}
        title={state.title ?? 'Vídeo do YouTube'}
        allow="autoplay; encrypted-media; picture-in-picture"
        allowFullScreen
      />
    </div>
  );
}

function ClockCanvas({ preview }: { preview: boolean }) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  return (
    <div className="presentation-canvas theme-midnight clock-canvas">
      <div className="ambient-orb" />
      <div className="clock-time">{now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
      <div className="clock-date">{now.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}</div>
      {!preview && <div className="clock-caption">O culto começará em breve</div>}
    </div>
  );
}
