import { useState, type FormEvent } from 'react';
import type { Song, SongSegment } from '../types';
import { Icon } from './Icons';

interface Props {
  onClose: () => void;
  onSave: (song: Omit<Song, 'id'>) => Promise<void>;
}

function parseSegments(value: string): SongSegment[] {
  const blocks = value.split(/\n\s*\n/).map((block) => block.trim()).filter(Boolean);
  return blocks.map((block, index) => {
    const lines = block.split('\n');
    const first = lines[0].trim();
    const isLabel = /^(INTRO|VERSO|REFRÃO|PONTE|FINAL|PRÉ-REFRÃO|CORO)/i.test(first);
    return {
      label: isLabel ? first.toUpperCase() : `PARTE ${index + 1}`,
      text: (isLabel ? lines.slice(1) : lines).join('\n').trim(),
    };
  }).filter((segment) => segment.text);
}

export function SongModal({ onClose, onSave }: Props) {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', artist: '', musicalKey: '', category: 'Adoração', lyrics: 'VERSO 1\n\nREFRÃO\n' });

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const segments = parseSegments(form.lyrics);
    if (!form.title.trim() || !segments.length) return;
    setSaving(true);
    await onSave({
      title: form.title.trim(),
      artist: form.artist.trim(),
      musicalKey: form.musicalKey.trim(),
      category: form.category,
      segments,
    });
    setSaving(false);
  };

  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <form className="song-modal" onSubmit={submit} onMouseDown={(event) => event.stopPropagation()}>
        <div className="modal-header">
          <div><span className="eyebrow">BIBLIOTECA</span><h2>Novo louvor</h2></div>
          <button type="button" className="icon-button" onClick={onClose}>×</button>
        </div>
        <div className="form-grid">
          <label className="field span-2">Título<input autoFocus value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex.: Grandioso És Tu" /></label>
          <label className="field">Artista<input value={form.artist} onChange={(e) => setForm({ ...form, artist: e.target.value })} placeholder="Nome do artista" /></label>
          <label className="field">Tom<input value={form.musicalKey} onChange={(e) => setForm({ ...form, musicalKey: e.target.value })} placeholder="Ex.: G" /></label>
          <label className="field span-2">Categoria<select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}><option>Adoração</option><option>Celebração</option><option>Ceia</option><option>Jovens</option><option>Crianças</option><option>Especiais</option></select></label>
          <label className="field span-2">Letra organizada por partes<textarea rows={12} value={form.lyrics} onChange={(e) => setForm({ ...form, lyrics: e.target.value })} placeholder={'VERSO 1\nLetra...\n\nREFRÃO\nLetra...'} /><small>Separe as partes com uma linha em branco. Use títulos como VERSO, REFRÃO e PONTE.</small></label>
        </div>
        <div className="modal-actions">
          <button type="button" className="button ghost" onClick={onClose}>Cancelar</button>
          <button className="button primary" disabled={saving}><Icon name="plus" />{saving ? 'Salvando...' : 'Salvar louvor'}</button>
        </div>
      </form>
    </div>
  );
}
