import { useMemo, useState, type FormEvent } from 'react';
import { parseYoutubeVideoId } from '../domain/presenter';
import type { MediaItem } from '../types';
import { Icon } from './Icons';

interface Props {
  onClose: () => void;
  onSave: (input: { url: string; videoId: string; title?: string }) => Promise<MediaItem>;
}

export function YoutubeModal({ onClose, onSave }: Props) {
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [saving, setSaving] = useState(false);
  const videoId = useMemo(() => parseYoutubeVideoId(url), [url]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!videoId) return;
    setSaving(true);
    try {
      await onSave({ url: url.trim(), videoId, title: title.trim() || undefined });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <form className="song-modal youtube-modal" onSubmit={submit} onMouseDown={(event) => event.stopPropagation()}>
        <div className="modal-header">
          <div><span className="eyebrow">MÍDIA ONLINE</span><h2>Adicionar vídeo do YouTube</h2></div>
          <button type="button" className="icon-button" onClick={onClose}>×</button>
        </div>
        <div className="youtube-form">
          <div className="youtube-callout"><Icon name="youtube" /><div><strong>Use o link original do vídeo</strong><span>Compatível com YouTube, youtu.be, Shorts e transmissões ao vivo.</span></div></div>
          <label className="field">Link do YouTube<input autoFocus value={url} onChange={(event) => setUrl(event.target.value)} placeholder="https://www.youtube.com/watch?v=..." /></label>
          {url && <div className={`url-status ${videoId ? 'valid' : 'invalid'}`}>{videoId ? '✓ Link reconhecido' : 'Link do YouTube não reconhecido'}</div>}
          <label className="field">Título opcional<input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="O título será buscado automaticamente" /></label>
          <p className="online-warning">Este item precisa de internet para tocar durante o culto. Para máxima segurança, mantenha conteúdos essenciais também em arquivo local.</p>
        </div>
        <div className="modal-actions">
          <button type="button" className="button ghost" onClick={onClose}>Cancelar</button>
          <button className="button youtube-button" disabled={!videoId || saving}><Icon name="youtube" />{saving ? 'Adicionando...' : 'Adicionar à biblioteca'}</button>
        </div>
      </form>
    </div>
  );
}
