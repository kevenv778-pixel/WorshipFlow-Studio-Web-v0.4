import type { MediaItem, PresentationState, ServiceItem, Song } from '../types';

export function mediaUrl(filePath: string) {
  const bytes = new TextEncoder().encode(filePath);
  let binary = '';
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  const encoded = btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
  return `wfmedia://media/${encoded}`;
}

export function parseYoutubeVideoId(value: string) {
  const candidate = value.trim();
  try {
    const url = new URL(candidate.startsWith('http') ? candidate : `https://${candidate}`);
    const host = url.hostname.replace(/^www\./, '').toLowerCase();
    let id: string | null = null;
    if (host === 'youtu.be') id = url.pathname.split('/').filter(Boolean)[0] ?? null;
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com') {
      if (url.pathname === '/watch') id = url.searchParams.get('v');
      const parts = url.pathname.split('/').filter(Boolean);
      if (['embed', 'shorts', 'live'].includes(parts[0])) id = parts[1] ?? null;
    }
    return id && /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
  } catch {
    return null;
  }
}

export function resolvePresentation(
  item: ServiceItem | undefined,
  slide: number,
  songs: Song[],
  media: MediaItem[],
): PresentationState {
  if (!item) return { mode: 'clear', theme: 'aurora' };
  if (item.type === 'song') {
    const song = songs.find((candidate) => candidate.id === item.contentId);
    const segment = song?.segments[Math.max(0, Math.min(slide, (song?.segments.length ?? 1) - 1))];
    return {
      mode: 'content',
      type: 'song',
      title: song?.title ?? item.title,
      subtitle: [song?.artist, song?.musicalKey && `Tom ${song.musicalKey}`].filter(Boolean).join(' • '),
      label: segment?.label,
      text: segment?.text ?? item.title,
      theme: 'aurora',
    };
  }
  if (item.type === 'video' || item.type === 'image') {
    const asset = media.find((candidate) => candidate.id === item.contentId);
    return {
      mode: 'content',
      type: item.type,
      title: asset?.title ?? item.title,
      mediaUrl: asset?.source !== 'youtube' && asset?.path ? mediaUrl(asset.path) : undefined,
      youtubeId: asset?.source === 'youtube' ? asset.videoId ?? parseYoutubeVideoId(asset.path) ?? undefined : undefined,
      theme: 'midnight',
    };
  }
  if (item.type === 'bible') {
    return {
      mode: 'content',
      type: 'bible',
      title: String(item.payload.reference ?? item.title),
      label: 'LEITURA BÍBLICA',
      text: String(item.payload.text ?? ''),
      theme: 'warm',
    };
  }
  return {
    mode: 'content',
    type: 'notice',
    title: item.title,
    text: String(item.payload.text ?? item.title),
    theme: 'aurora',
  };
}

export function slideCount(item: ServiceItem | undefined, songs: Song[]) {
  if (!item || item.type !== 'song') return 1;
  return songs.find((song) => song.id === item.contentId)?.segments.length ?? 1;
}
