import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import { ProjectorView } from './ProjectorView';
import { StudioApp } from './studio/StudioApp';
import { StudioOutput } from './studio/StudioOutput';
import './styles/app.css';
import './styles/studio.css';

const params = new URLSearchParams(window.location.search);
const view = params.get('view');
const Root = view === 'projector'
  ? ProjectorView
  : view === 'studio-output'
    ? StudioOutput
    : window.worshipFlow
      ? App
      : StudioApp;

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>,
);
