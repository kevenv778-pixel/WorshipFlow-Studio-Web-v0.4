import { useEffect, useMemo, useRef } from 'react';
import { parseYoutubeVideoId } from '../domain/presenter';
import { getStream } from './runtime';
import type { StudioAsset, StudioScene, StudioSource } from './types';

interface Props {
  scene: StudioScene | null;
  assets?: StudioAsset[];
  preview?: boolean;
  compact?: boolean;
  revision?: number;
}

export function SceneCanvas({ scene, assets = [], preview = false, compact = false, revision = 0 }: Props) {
  const sources = useMemo(() => scene?.sources.filter((source) => source.visible) ?? [], [scene]);
  if (!scene) return <div className="studio-canvas empty"><div className="studio-empty-mark"><span /><span /><span /></div><strong>Nenhuma cena no programa</strong><small>Selecione uma cena e envie ao vivo</small></div>;

  return (
    <div key={`${scene.id}-${revision}`} className={`studio-canvas scene-transition-${scene.transition} ${compact ? 'compact' : ''}`} style={{ background: scene.background }}>
      <div className="studio-canvas-grid" />
      {sources.map((source, index) => (
        <SourceLayer key={source.id} source={source} asset={assets.find((asset) => asset.id === source.assetId)} preview={preview} zIndex={index + 1} />
      ))}
      {!sources.length && <div className="scene-placeholder"><strong>{scene.name}</strong><span>Adicione uma fonte a esta cena</span></div>}
      <div className="scene-corner-label">{scene.name}</div>
    </div>
  );
}

function SourceLayer({ source, asset, preview, zIndex }: { source: StudioSource; asset?: StudioAsset; preview: boolean; zIndex: number }) {
  const className = `studio-source-layer layout-${source.layout} source-${source.kind}`;
  const style = { zIndex };
  const url = asset?.url ?? source.url;

  if (source.kind === 'camera' || source.kind === 'screen') {
    return <div className={className} style={style}><StreamVideo streamId={source.streamId} muted={preview || source.muted} volume={source.volume} name={source.name} /></div>;
  }
  if (source.kind === 'video' && url) {
    return <div className={className} style={style}><MediaVideo url={url} muted={preview || source.muted} volume={source.volume} /></div>;
  }
  if (source.kind === 'audio' && url) {
    return <div className={`${className} audio-layer`} style={style}><MediaAudio url={url} muted={preview || source.muted} volume={source.volume} /><div className="audio-visual"><i /><i /><i /><i /><i /><span>{source.name}</span></div></div>;
  }
  if (source.kind === 'image' && url) {
    return <div className={className} style={style}><img src={url} alt={source.name} /></div>;
  }
  if (source.kind === 'slides' && url) {
    return <div className={className} style={style}><iframe src={`${url}#toolbar=0&navpanes=0`} title={source.name} /></div>;
  }
  if (source.kind === 'youtube') {
    const videoId = source.youtubeId ?? (source.url ? parseYoutubeVideoId(source.url) : null);
    if (videoId) {
      const params = new URLSearchParams({ autoplay: preview ? '0' : '1', controls: '1', rel: '0', playsinline: '1' });
      if (preview) params.set('mute', '1');
      if (window.location.origin.startsWith('http')) params.set('origin', window.location.origin);
      return <div className={className} style={style}><iframe src={`https://www.youtube.com/embed/${videoId}?${params.toString()}`} title={source.name} allow="autoplay; encrypted-media; picture-in-picture" /></div>;
    }
  }
  if (source.kind === 'lyrics') {
    return <div className={className} style={style}><div className="lyrics-content"><span>LOUVOR</span><strong>{source.content}</strong><small>{source.name}</small></div></div>;
  }
  if (source.kind === 'text') {
    return <div className={className} style={style}><div className="text-content" style={{ color: source.color ?? '#ffffff' }}>{source.content}</div></div>;
  }
  return <div className={`${className} disconnected`} style={style}><strong>{source.name}</strong><span>Fonte desconectada — reconecte no painel</span></div>;
}

function StreamVideo({ streamId, muted, volume, name }: { streamId?: string; muted: boolean; volume: number; name: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  const stream = getStream(streamId);
  useEffect(() => {
    if (!ref.current || !stream) return;
    ref.current.srcObject = stream;
    ref.current.volume = volume;
    void ref.current.play().catch(() => undefined);
  }, [stream, volume]);
  if (!stream) return <div className="stream-missing"><strong>{name}</strong><span>Aguardando conexão da fonte</span></div>;
  return <video ref={ref} autoPlay playsInline muted={muted} />;
}

function MediaVideo({ url, muted, volume }: { url: string; muted: boolean; volume: number }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => { if (ref.current) ref.current.volume = volume; }, [volume]);
  return <video ref={ref} src={url} autoPlay loop playsInline muted={muted} />;
}

function MediaAudio({ url, muted, volume }: { url: string; muted: boolean; volume: number }) {
  const ref = useRef<HTMLAudioElement>(null);
  useEffect(() => { if (ref.current) ref.current.volume = volume; }, [volume]);
  return <audio ref={ref} src={url} autoPlay loop muted={muted} />;
}

