import { useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { Icon } from '../components/Icons';
import { parseYoutubeVideoId } from '../domain/presenter';
import { registerStream } from './runtime';
import { saveAsset } from './storage';
import type { StudioAsset, StudioSource, StudioSourceKind } from './types';

interface Props {
  onClose: () => void;
  onAdd: (source: StudioSource, asset?: StudioAsset) => void;
}

const sourceOptions: Array<{ kind: StudioSourceKind; icon: string; title: string; description: string }> = [
  { kind: 'camera', icon: 'camera', title: 'Câmera', description: 'Webcam ou placa de captura' },
  { kind: 'screen', icon: 'screenShare', title: 'Captura de tela', description: 'Tela, janela ou aplicativo' },
  { kind: 'video', icon: 'folder', title: 'Arquivo local', description: 'Vídeo, áudio, imagem ou PDF' },
  { kind: 'youtube', icon: 'youtube', title: 'YouTube', description: 'Vídeo, Short ou transmissão' },
  { kind: 'lyrics', icon: 'music', title: 'Letra de louvor', description: 'Texto central para congregação' },
  { kind: 'text', icon: 'text', title: 'Texto e legenda', description: 'Título, aviso ou rodapé' },
];

export function SourceModal({ onClose, onAdd }: Props) {
  const [kind, setKind] = useState<StudioSourceKind | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [name, setName] = useState('');
  const [content, setContent] = useState('');
  const [url, setUrl] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  function baseSource(sourceKind: StudioSourceKind, sourceName: string): StudioSource {
    return {
      id: crypto.randomUUID(),
      name: sourceName,
      kind: sourceKind,
      visible: true,
      muted: false,
      volume: 1,
      layout: sourceKind === 'text' ? 'lower-third' : sourceKind === 'lyrics' ? 'center' : 'full',
    };
  }

  async function selectKind(nextKind: StudioSourceKind) {
    setError('');
    if (nextKind === 'camera') {
      setBusy(true);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        const source = baseSource('camera', 'Câmera principal');
        source.streamId = registerStream(stream);
        onAdd(source);
      } catch {
        setError('Não foi possível acessar a câmera. Verifique a permissão do navegador.');
      } finally { setBusy(false); }
      return;
    }
    if (nextKind === 'screen') {
      setBusy(true);
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
        const source = baseSource('screen', 'Captura de tela');
        source.streamId = registerStream(stream);
        onAdd(source);
      } catch {
        setError('A captura foi cancelada ou não recebeu permissão.');
      } finally { setBusy(false); }
      return;
    }
    if (nextKind === 'video') {
      fileRef.current?.click();
      return;
    }
    setKind(nextKind);
  }

  async function selectFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const asset = await saveAsset(file);
      const source = baseSource(asset.kind, file.name.replace(/\.[^.]+$/, ''));
      source.assetId = asset.id;
      source.muted = asset.kind === 'audio';
      onAdd(source, asset);
    } catch {
      setError('Não foi possível salvar o arquivo no navegador.');
    } finally { setBusy(false); }
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    if (!kind) return;
    if (kind === 'youtube') {
      const videoId = parseYoutubeVideoId(url);
      if (!videoId) { setError('Cole um link válido do YouTube.'); return; }
      onAdd({ ...baseSource('youtube', name.trim() || 'Vídeo do YouTube'), url: url.trim(), youtubeId: videoId });
      return;
    }
    if ((kind === 'text' || kind === 'lyrics') && content.trim()) {
      onAdd({ ...baseSource(kind, name.trim() || (kind === 'lyrics' ? 'Louvor' : 'Texto')), content: content.trim(), color: '#ffffff' });
    }
  }

  return (
    <div className="studio-modal-backdrop" onMouseDown={onClose}>
      <div className="studio-modal" onMouseDown={(event) => event.stopPropagation()}>
        <header><div><span>NOVA FONTE</span><h2>{kind ? sourceOptions.find((option) => option.kind === kind)?.title : 'Adicionar conteúdo à cena'}</h2></div><button onClick={onClose}>×</button></header>
        {!kind ? (
          <div className="source-picker">
            {sourceOptions.map((option) => <button key={option.kind} disabled={busy} onClick={() => void selectKind(option.kind)}><i className={`source-pick-icon kind-${option.kind}`}><Icon name={option.icon} /></i><span><strong>{option.title}</strong><small>{option.description}</small></span><Icon name="chevronRight" /></button>)}
          </div>
        ) : (
          <form className="source-form" onSubmit={submit}>
            {kind === 'youtube' && <><label>Link do YouTube<input autoFocus value={url} onChange={(event) => setUrl(event.target.value)} placeholder="https://youtube.com/watch?v=..." /></label><label>Nome no painel<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Opcional" /></label></>}
            {(kind === 'text' || kind === 'lyrics') && <><label>Nome da fonte<input autoFocus value={name} onChange={(event) => setName(event.target.value)} placeholder={kind === 'lyrics' ? 'Nome do louvor' : 'Ex.: Aviso principal'} /></label><label>{kind === 'lyrics' ? 'Trecho da letra' : 'Conteúdo'}<textarea rows={7} value={content} onChange={(event) => setContent(event.target.value)} placeholder={kind === 'lyrics' ? 'Digite o trecho que aparecerá no telão' : 'Digite o texto'} /></label></>}
            <div className="source-form-actions"><button type="button" className="studio-button secondary" onClick={() => setKind(null)}>Voltar</button><button className="studio-button primary">Adicionar à cena</button></div>
          </form>
        )}
        {error && <div className="studio-error">{error}</div>}
        {busy && <div className="studio-busy"><span />Aguardando permissão...</div>}
        <input ref={fileRef} hidden type="file" accept="video/*,audio/*,image/*,application/pdf" onChange={(event) => void selectFile(event)} />
      </div>
    </div>
  );
}

