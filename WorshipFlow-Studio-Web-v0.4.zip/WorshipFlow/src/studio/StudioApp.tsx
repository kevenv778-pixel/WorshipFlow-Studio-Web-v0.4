import { useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from '../components/Icons';
import { SceneCanvas } from './SceneCanvas';
import { SourceModal } from './SourceModal';
import { hydrateScene, outputUrl, publishProgram, stopStream } from './runtime';
import { loadAssets, loadProject, saveProject } from './storage';
import type { SceneTransition, SourceLayout, StudioAsset, StudioProject, StudioScene, StudioSource, StudioSourceKind, StudioView } from './types';

const sourceMeta: Record<StudioSourceKind, { label: string; icon: string }> = {
  video: { label: 'Vídeo', icon: 'video' }, audio: { label: 'Áudio', icon: 'volume' }, image: { label: 'Imagem', icon: 'image' }, youtube: { label: 'YouTube', icon: 'youtube' }, camera: { label: 'Câmera', icon: 'camera' }, screen: { label: 'Captura', icon: 'screenShare' }, text: { label: 'Texto', icon: 'text' }, lyrics: { label: 'Letra', icon: 'music' }, slides: { label: 'Apresentação', icon: 'slides' },
};

const layoutLabels: Record<SourceLayout, string> = {
  full: 'Tela cheia', 'pip-bottom-right': 'PIP inferior', 'pip-top-right': 'PIP superior', center: 'Centralizado', 'lower-third': 'Rodapé',
};

const transitionLabels: Record<SceneTransition, string> = { cut: 'Corte direto', fade: 'Fade', dissolve: 'Dissolver', slide: 'Deslizar' };

function defaultProject(): StudioProject {
  const welcomeId = crypto.randomUUID();
  const worshipId = crypto.randomUUID();
  const sermonId = crypto.randomUUID();
  const noticeId = crypto.randomUUID();
  return {
    id: crypto.randomUUID(), name: 'Culto de Domingo', previewSceneId: welcomeId, liveSceneId: null,
    scenes: [
      scene(welcomeId, 'Boas-vindas', 'fade', '#0a1325', [{ ...source('text', 'Mensagem de abertura'), content: 'Sejam todos bem-vindos', layout: 'center' }]),
      scene(worshipId, 'Louvor', 'dissolve', '#121934', [{ ...source('lyrics', 'Louvor congregacional'), content: 'Tua graça e bondade permanecerão\nPara sempre cantaremos', layout: 'center' }]),
      scene(sermonId, 'Pregação', 'fade', '#07121c', [{ ...source('text', 'Tema da mensagem'), content: 'Tempo para anunciar Jesus a todas as pessoas', layout: 'lower-third' }]),
      scene(noticeId, 'Avisos', 'slide', '#151124', [{ ...source('text', 'Próximas atividades'), content: 'Acompanhe os próximos anúncios', layout: 'center' }]),
    ],
  };
}

function source(kind: StudioSourceKind, name: string): StudioSource {
  return { id: crypto.randomUUID(), name, kind, visible: true, muted: false, volume: 1, layout: 'full', color: '#ffffff' };
}

function scene(id: string, name: string, transition: SceneTransition, background: string, sources: StudioSource[]): StudioScene {
  return { id, name, transition, duration: 500, background, sources };
}

export function StudioApp() {
  const [project, setProject] = useState<StudioProject>(() => loadProject() ?? defaultProject());
  const [assets, setAssets] = useState<StudioAsset[]>([]);
  const [view, setView] = useState<StudioView>('studio');
  const [showSourceModal, setShowSourceModal] = useState(false);
  const [blackout, setBlackout] = useState(false);
  const [revision, setRevision] = useState(0);
  const [toast, setToast] = useState('');
  const [recording, setRecording] = useState(false);
  const [now, setNow] = useState(() => new Date());
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordingStreamRef = useRef<MediaStream | null>(null);

  useEffect(() => { void loadAssets().then(setAssets); }, []);
  useEffect(() => saveProject(project), [project]);
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const previewScene = project.scenes.find((item) => item.id === project.previewSceneId) ?? project.scenes[0];
  const liveScene = project.scenes.find((item) => item.id === project.liveSceneId) ?? null;
  const hydratedLive = useMemo(() => hydrateScene(liveScene, assets), [liveScene, assets]);

  useEffect(() => {
    publishProgram({ scene: hydratedLive, blackout, revision });
  }, [hydratedLive, blackout, revision]);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (event.key === 'F1') { event.preventDefault(); setBlackout((current) => !current); }
      if (event.key === 'F2') { event.preventDefault(); movePreview(1); }
      if (event.key === 'F3') { event.preventDefault(); movePreview(-1); }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  function updatePreviewScene(updater: (current: StudioScene) => StudioScene) {
    setProject((current) => ({ ...current, scenes: current.scenes.map((item) => item.id === current.previewSceneId ? updater(item) : item) }));
  }

  function addScene() {
    const id = crypto.randomUUID();
    const next = scene(id, `Nova cena ${project.scenes.length + 1}`, 'fade', '#08111f', []);
    setProject((current) => ({ ...current, scenes: [...current.scenes, next], previewSceneId: id }));
  }

  function duplicateScene(sceneToCopy: StudioScene) {
    const copy = { ...sceneToCopy, id: crypto.randomUUID(), name: `${sceneToCopy.name} — cópia`, sources: sceneToCopy.sources.map((item) => ({ ...item, id: crypto.randomUUID() })) };
    setProject((current) => ({ ...current, scenes: [...current.scenes, copy], previewSceneId: copy.id }));
  }

  function movePreview(direction: -1 | 1) {
    setProject((current) => {
      const index = current.scenes.findIndex((item) => item.id === current.previewSceneId);
      const nextIndex = Math.max(0, Math.min(current.scenes.length - 1, index + direction));
      return { ...current, previewSceneId: current.scenes[nextIndex]?.id ?? current.previewSceneId };
    });
  }

  function moveScene(sceneId: string, direction: -1 | 1) {
    setProject((current) => {
      const scenes = [...current.scenes];
      const index = scenes.findIndex((item) => item.id === sceneId);
      const nextIndex = Math.max(0, Math.min(scenes.length - 1, index + direction));
      if (index === nextIndex) return current;
      const [moved] = scenes.splice(index, 1);
      scenes.splice(nextIndex, 0, moved);
      return { ...current, scenes };
    });
  }

  function removeScene(sceneId: string) {
    if (project.scenes.length === 1) { setToast('O projeto precisa ter pelo menos uma cena'); return; }
    const target = project.scenes.find((item) => item.id === sceneId);
    target?.sources.forEach((item) => stopStream(item.streamId));
    setProject((current) => {
      const scenes = current.scenes.filter((item) => item.id !== sceneId);
      return { ...current, scenes, previewSceneId: current.previewSceneId === sceneId ? scenes[0].id : current.previewSceneId, liveSceneId: current.liveSceneId === sceneId ? null : current.liveSceneId };
    });
  }

  function addSource(nextSource: StudioSource, asset?: StudioAsset) {
    if (asset) setAssets((current) => [...current, asset]);
    updatePreviewScene((current) => ({ ...current, sources: [...current.sources, nextSource] }));
    setShowSourceModal(false);
    setToast(`${nextSource.name} adicionado à cena`);
  }

  function updateSource(sourceId: string, patch: Partial<StudioSource>) {
    updatePreviewScene((current) => ({ ...current, sources: current.sources.map((item) => item.id === sourceId ? { ...item, ...patch } : item) }));
  }

  function removeSource(sourceId: string) {
    const target = previewScene.sources.find((item) => item.id === sourceId);
    stopStream(target?.streamId);
    updatePreviewScene((current) => ({ ...current, sources: current.sources.filter((item) => item.id !== sourceId) }));
  }

  function moveSource(sourceId: string, direction: -1 | 1) {
    updatePreviewScene((current) => {
      const sources = [...current.sources];
      const index = sources.findIndex((item) => item.id === sourceId);
      const nextIndex = Math.max(0, Math.min(sources.length - 1, index + direction));
      const [moved] = sources.splice(index, 1);
      sources.splice(nextIndex, 0, moved);
      return { ...current, sources };
    });
  }

  function sendLive() {
    setProject((current) => ({ ...current, liveSceneId: current.previewSceneId }));
    setBlackout(false);
    setRevision((current) => current + 1);
    setToast(`${previewScene.name} está no programa`);
  }

  function openOutput() {
    const output = window.open(outputUrl(), 'worshipflow-output', 'popup=yes,width=1280,height=720');
    if (!output) setToast('Permita janelas pop-up para abrir a saída');
    else { output.focus(); window.setTimeout(() => publishProgram({ scene: hydratedLive, blackout, revision }), 500); }
  }

  async function copyOutput() {
    await navigator.clipboard.writeText(outputUrl());
    setToast('Link da saída copiado');
  }

  async function toggleRecording() {
    if (recording && recorderRef.current) {
      recorderRef.current.stop();
      recordingStreamRef.current?.getTracks().forEach((track) => track.stop());
      setRecording(false);
      return;
    }
    try {
      const capture = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 30 }, audio: true });
      const chunks: BlobPart[] = [];
      const recorder = new MediaRecorder(capture, { mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus') ? 'video/webm;codecs=vp9,opus' : 'video/webm' });
      recorder.ondataavailable = (event) => { if (event.data.size) chunks.push(event.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const anchor = document.createElement('a');
        anchor.href = URL.createObjectURL(blob);
        anchor.download = `WorshipFlow-${new Date().toISOString().replace(/[:.]/g, '-')}.webm`;
        anchor.click();
        URL.revokeObjectURL(anchor.href);
      };
      recorderRef.current = recorder;
      recordingStreamRef.current = capture;
      recorder.start(1000);
      capture.getVideoTracks()[0]?.addEventListener('ended', () => { if (recorder.state !== 'inactive') recorder.stop(); setRecording(false); });
      setRecording(true);
      setToast('Gravação iniciada');
    } catch { setToast('A gravação foi cancelada'); }
  }

  return (
    <div className="studio-shell">
      <header className="studio-topbar">
        <div className="studio-brand"><div className="brand-mark"><span /><span /><span /></div><div><strong>Worship<span>Flow</span></strong><small>STUDIO LOCAL</small></div></div>
        <div className="studio-event"><span>PROGRAMAÇÃO ATUAL</span><strong>{project.name}</strong></div>
        <nav>
          <button className={view === 'studio' ? 'active' : ''} onClick={() => setView('studio')}><Icon name="layers" />Estúdio</button>
          <button className={view === 'media' ? 'active' : ''} onClick={() => setView('media')}><Icon name="folder" />Mídia</button>
          <button className={view === 'schedule' ? 'active' : ''} onClick={() => setView('schedule')}><Icon name="schedule" />Programação</button>
          <button className={view === 'broadcast' ? 'active' : ''} onClick={() => setView('broadcast')}><Icon name="broadcast" />Transmissão</button>
        </nav>
        <div className="studio-top-actions"><div className="studio-clock"><strong>{now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</strong><span>{now.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short' }).replace('.', '')}</span></div><span className="local-status"><i />LOCAL</span><button className={recording ? 'recording' : ''} onClick={() => void toggleRecording()}><Icon name={recording ? 'stop' : 'record'} />{recording ? 'Parar' : 'Gravar'}</button><button className="output-button" onClick={openOutput}><Icon name="external" />Abrir telão</button></div>
      </header>

      {view === 'studio' && <div className="studio-workspace">
        <aside className="scene-panel">
          <div className="studio-panel-title"><div><span>CENAS</span><h2>Produção</h2></div><button onClick={addScene}><Icon name="plus" /></button></div>
          <div className="scene-list">{project.scenes.map((item, index) => <button key={item.id} onClick={() => setProject((current) => ({ ...current, previewSceneId: item.id }))} className={`scene-card ${item.id === project.previewSceneId ? 'selected' : ''} ${item.id === project.liveSceneId ? 'live' : ''}`}><span className="scene-index">{String(index + 1).padStart(2, '0')}</span><div className="scene-thumb"><SceneCanvas scene={item} assets={assets} preview compact /></div><div className="scene-name"><strong>{item.name}</strong><small>{item.sources.length} fontes • {transitionLabels[item.transition]}</small></div>{item.id === project.liveSceneId ? <span className="scene-state program">PGM</span> : item.id === project.previewSceneId ? <span className="scene-state preview">PVW</span> : null}</button>)}</div>
          <div className="scene-actions"><button onClick={() => moveScene(previewScene.id, -1)}>↑<span>Subir</span></button><button onClick={() => moveScene(previewScene.id, 1)}>↓<span>Descer</span></button><button onClick={() => duplicateScene(previewScene)}><Icon name="duplicate" />Duplicar</button><button onClick={() => removeScene(previewScene.id)}><Icon name="trash" />Excluir</button></div>
        </aside>

        <main className="studio-center">
          <div className="production-heading"><div><span>MESA DE PRODUÇÃO</span><h1>Controle de exibição</h1></div><div className="production-health"><span><i />Sistema pronto</span><span>{assets.length} mídias</span><span>{project.scenes.length} cenas</span></div></div>
          <div className="monitor-grid">
            <section className="monitor-card preview-card">
              <header><div className="monitor-status preview"><i />PRÉVIA</div><input className="scene-title-input" aria-label="Nome da cena" value={previewScene.name} onChange={(event) => updatePreviewScene((current) => ({ ...current, name: event.target.value }))} /><span>{previewScene.sources.length} fontes</span></header>
              <div className="monitor-frame"><SceneCanvas scene={previewScene} assets={assets} preview /></div>
              <footer><span>Preparando</span><strong>{previewScene.name}</strong><kbd>PVW</kbd></footer>
            </section>
            <section className={`monitor-card program-card ${blackout ? 'is-blackout' : ''}`}>
              <header><div className="monitor-status program"><i />NO AR</div><strong>{blackout ? 'Blackout' : liveScene?.name ?? 'Aguardando exibição'}</strong><span>{liveScene?.sources.length ?? 0} fontes</span></header>
              <div className="monitor-frame">{blackout ? <div className="monitor-blackout"><Icon name="blackout" /><strong>BLACKOUT</strong><span>O telão está preto</span></div> : <SceneCanvas scene={liveScene} assets={assets} preview />}</div>
              <footer><span>{blackout ? 'Tela protegida' : liveScene ? 'Transmitindo agora' : 'Saída em espera'}</span><strong>{blackout ? 'Tela preta ativa' : liveScene?.name ?? 'Nenhuma cena'}</strong><kbd>PGM</kbd></footer>
            </section>
          </div>
          <div className="transition-desk">
            <button className="scene-nav" onClick={() => movePreview(-1)}><Icon name="chevronLeft" /><span>Anterior</span><kbd>F3</kbd></button>
            <div className="transition-settings"><label><Icon name="transition" /><select value={previewScene.transition} onChange={(event) => updatePreviewScene((current) => ({ ...current, transition: event.target.value as SceneTransition }))}>{Object.entries(transitionLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label><label className="duration-control"><input aria-label="Duração da transição" type="range" min="0" max="2000" step="100" value={previewScene.duration} onChange={(event) => updatePreviewScene((current) => ({ ...current, duration: Number(event.target.value) }))} /><span>{previewScene.duration}ms</span></label></div>
            <button className="take-button" onClick={sendLive}><span>EXIBIR</span><small>Enviar prévia ao programa</small><Icon name="chevronRight" /></button>
            <button className="scene-nav next" onClick={() => movePreview(1)}><span>Próxima</span><Icon name="chevronRight" /><kbd>F2</kbd></button>
          </div>
          <div className="emergency-desk"><div className="studio-shortcuts"><span><kbd>F1</kbd> Blackout</span><span><kbd>F2</kbd> Próxima</span><span><kbd>F3</kbd> Anterior</span></div><div><button className={`blackout-control ${blackout ? 'active' : ''}`} onClick={() => setBlackout((current) => !current)}><Icon name="blackout" />{blackout ? 'Remover blackout' : 'Blackout'}</button><button className="output-control" onClick={openOutput}><Icon name="external" />Abrir saída</button></div></div>
        </main>

        <aside className="source-panel">
          <div className="studio-panel-title"><div><span>COMPOSIÇÃO</span><h2>Fontes</h2></div><button className="add-source" onClick={() => setShowSourceModal(true)}><Icon name="plus" />Adicionar</button></div>
          <div className="source-list">{[...previewScene.sources].reverse().map((item, reverseIndex) => {
            const originalIndex = previewScene.sources.length - 1 - reverseIndex;
            const meta = sourceMeta[item.kind];
            return <div className={`source-control-card ${item.visible ? '' : 'hidden-source'}`} key={item.id}><div className="source-row"><span className={`source-kind kind-${item.kind}`}><Icon name={meta.icon} /></span><div><strong>{item.name}</strong><small>{meta.label}<i className={item.visible ? 'source-online' : ''}>{item.visible ? 'Ativa' : 'Oculta'}</i></small></div><button title="Mostrar/ocultar" aria-label={`Mostrar ou ocultar ${item.name}`} onClick={() => updateSource(item.id, { visible: !item.visible })}><Icon name={item.visible ? 'eye' : 'eyeOff'} /></button><button title="Remover" aria-label={`Remover ${item.name}`} onClick={() => removeSource(item.id)}><Icon name="trash" /></button></div><div className="source-settings"><label title="Volume"><Icon name={item.muted ? 'mute' : 'volume'} /><input type="range" min="0" max="1" step="0.05" value={item.volume} onChange={(event) => updateSource(item.id, { volume: Number(event.target.value), muted: false })} /></label><button title="Silenciar" className={item.muted ? 'active' : ''} onClick={() => updateSource(item.id, { muted: !item.muted })}><Icon name={item.muted ? 'mute' : 'volume'} /></button><select aria-label={`Posição de ${item.name}`} value={item.layout} onChange={(event) => updateSource(item.id, { layout: event.target.value as SourceLayout })}>{Object.entries(layoutLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select><div className="layer-order"><button title="Subir camada" disabled={originalIndex === previewScene.sources.length - 1} onClick={() => moveSource(item.id, 1)}>↑</button><button title="Descer camada" disabled={originalIndex === 0} onClick={() => moveSource(item.id, -1)}>↓</button></div></div></div>;
          })}{!previewScene.sources.length && <div className="empty-sources"><Icon name="layers" /><strong>Cena vazia</strong><span>Adicione câmera, tela, mídia ou texto</span><button onClick={() => setShowSourceModal(true)}>Adicionar primeira fonte</button></div>}</div>
          <div className="master-audio"><div><Icon name="volume" /><span><strong>Áudio mestre</strong><small>{previewScene.sources.filter((item) => !item.muted).length} canais ativos</small></span></div><div className="master-meter"><i /><i /><i /><i /><i /><i /><i /></div></div>
        </aside>
      </div>}

      {view === 'media' && <MediaView assets={assets} onAdd={(asset) => { const next = source(asset.kind, asset.name.replace(/\.[^.]+$/, '')); next.assetId = asset.id; addSource(next); setView('studio'); }} onOpenPicker={() => setShowSourceModal(true)} />}
      {view === 'schedule' && <ScheduleView project={project} assets={assets} onSelect={(id) => { setProject((current) => ({ ...current, previewSceneId: id })); setView('studio'); }} onLive={(id) => { setProject((current) => ({ ...current, previewSceneId: id, liveSceneId: id })); setRevision((current) => current + 1); }} />}
      {view === 'broadcast' && <BroadcastView recording={recording} onRecord={() => void toggleRecording()} onOpen={openOutput} onCopy={() => void copyOutput()} url={outputUrl()} />}

      {showSourceModal && <SourceModal onClose={() => setShowSourceModal(false)} onAdd={addSource} />}
      {toast && <div className="studio-toast"><span>✓</span>{toast}</div>}
    </div>
  );
}

function MediaView({ assets, onAdd, onOpenPicker }: { assets: StudioAsset[]; onAdd: (asset: StudioAsset) => void; onOpenPicker: () => void }) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | StudioAsset['kind']>('all');
  const visibleAssets = assets.filter((asset) => (filter === 'all' || asset.kind === filter) && asset.name.toLocaleLowerCase('pt-BR').includes(query.toLocaleLowerCase('pt-BR')));
  return <main className="studio-page media-page"><header><div><span>BIBLIOTECA LOCAL</span><h1>Central de mídia</h1><p>Organize seus arquivos locais e encontre rapidamente o conteúdo do evento.</p></div><button className="studio-button primary" onClick={onOpenPicker}><Icon name="plus" />Importar conteúdo</button></header><div className="library-toolbar"><label><Icon name="search" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Pesquisar na biblioteca" /></label><div className="media-filters">{([['all', 'Todos'], ['video', 'Vídeos'], ['audio', 'Áudios'], ['image', 'Imagens'], ['slides', 'Apresentações']] as const).map(([value, label]) => <button key={value} className={filter === value ? 'active' : ''} onClick={() => setFilter(value)}>{label}<span>{value === 'all' ? assets.length : assets.filter((asset) => asset.kind === value).length}</span></button>)}</div></div><div className="asset-grid">{visibleAssets.map((asset) => <article key={asset.id}><div className="asset-preview">{asset.kind === 'image' ? <img src={asset.url} alt={asset.name} /> : asset.kind === 'video' ? <video src={asset.url} muted /> : <Icon name={sourceMeta[asset.kind].icon} />}</div><div><span>{sourceMeta[asset.kind].label}</span><strong>{asset.name}</strong><small>{formatBytes(asset.size)} • disponível offline</small></div><button onClick={() => onAdd(asset)}><Icon name="plus" />Adicionar à cena</button></article>)}{!visibleAssets.length && <div className="page-empty"><Icon name={assets.length ? 'search' : 'folder'} /><strong>{assets.length ? 'Nenhum resultado encontrado' : 'Nenhuma mídia importada'}</strong><span>{assets.length ? 'Tente outro termo ou selecione outro filtro.' : 'Adicione vídeos, músicas, imagens ou apresentações em PDF.'}</span>{!assets.length && <button onClick={onOpenPicker}>Importar primeira mídia</button>}</div>}</div></main>;
}

function ScheduleView({ project, assets, onSelect, onLive }: { project: StudioProject; assets: StudioAsset[]; onSelect: (id: string) => void; onLive: (id: string) => void }) {
  const sourceCount = project.scenes.reduce((total, item) => total + item.sources.length, 0);
  return <main className="studio-page schedule-page"><header><div><span>PROGRAMAÇÃO DO EVENTO</span><h1>{project.name}</h1><p>Prepare cada momento antecipadamente e envie ao vivo com segurança.</p></div><div className="schedule-summary"><span><strong>{project.scenes.length}</strong>Cenas</span><span><strong>{sourceCount}</strong>Fontes</span><span><strong>{assets.length}</strong>Mídias</span></div></header><div className="schedule-timeline">{project.scenes.map((item, index) => <article className={item.id === project.liveSceneId ? 'is-live' : ''} key={item.id}><span className="schedule-number">{String(index + 1).padStart(2, '0')}</span><div className="schedule-preview"><SceneCanvas scene={item} assets={assets} preview compact /></div><div className="schedule-copy"><strong>{item.name}</strong><span>{item.sources.length} fontes • {transitionLabels[item.transition]} • {item.duration}ms</span></div>{item.id === project.liveSceneId && <span className="schedule-live-label"><i />NO AR</span>}<button onClick={() => onSelect(item.id)}>Preparar</button><button className="live-now" onClick={() => onLive(item.id)}>Exibir agora</button></article>)}</div></main>;
}

function BroadcastView({ recording, onRecord, onOpen, onCopy, url }: { recording: boolean; onRecord: () => void; onOpen: () => void; onCopy: () => void; url: string }) {
  return <main className="studio-page broadcast-page"><header><div><span>SAÍDA DE TRANSMISSÃO</span><h1>Transmissão e gravação</h1><p>Use a saída limpa no OBS ou grave a produção diretamente pelo navegador.</p></div></header><div className="broadcast-grid"><section className="broadcast-card featured"><div className="broadcast-icon"><Icon name="broadcast" /></div><span>SAÍDA LIMPA</span><h2>Janela para telão ou OBS</h2><p>Abra uma janela sem controles para enviar ao projetor ou capturar como fonte de navegador no OBS.</p><div className="output-url"><code>{url}</code><button onClick={onCopy}><Icon name="copy" />Copiar</button></div><button className="studio-button primary" onClick={onOpen}><Icon name="external" />Abrir saída agora</button></section><section className="broadcast-card"><div className={`broadcast-icon ${recording ? 'danger' : ''}`}><Icon name={recording ? 'stop' : 'record'} /></div><span>GRAVAÇÃO LOCAL</span><h2>{recording ? 'Gravação em andamento' : 'Gravar o evento'}</h2><p>Selecione a janela de saída do WorshipFlow. Ao finalizar, o vídeo será salvo em formato WebM.</p><button className={`studio-button ${recording ? 'danger' : 'secondary'}`} onClick={onRecord}><Icon name={recording ? 'stop' : 'record'} />{recording ? 'Parar e salvar' : 'Iniciar gravação'}</button></section><section className="broadcast-card roadmap"><div className="broadcast-icon"><Icon name="signal" /></div><span>PRÓXIMA ETAPA</span><h2>RTMP integrado</h2><p>A transmissão direta para YouTube, Facebook e outras plataformas requer um serviço local de codificação com FFmpeg e chave de transmissão.</p><div className="roadmap-status"><i />Arquitetura preparada</div></section></div></main>;
}

function formatBytes(value: number) {
  if (value < 1024 * 1024) return `${Math.max(1, Math.round(value / 1024))} KB`;
  return `${(value / 1024 / 1024).toFixed(1)} MB`;
}
