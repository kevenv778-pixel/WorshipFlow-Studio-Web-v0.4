import { useEffect, useState } from 'react';
import { readProgram, subscribeProgram } from './runtime';
import { SceneCanvas } from './SceneCanvas';
import type { ProgramPayload } from './types';

export function StudioOutput() {
  const [program, setProgram] = useState<ProgramPayload>(() => readProgram());
  useEffect(() => subscribeProgram(setProgram), []);

  if (program.blackout) return <main className="studio-output blackout" />;
  return <main className="studio-output"><SceneCanvas scene={program.scene} revision={program.revision} /></main>;
}

