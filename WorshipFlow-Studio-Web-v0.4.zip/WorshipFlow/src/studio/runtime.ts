import type { ProgramPayload, StudioAsset, StudioScene } from './types';

declare global {
  interface Window {
    __worshipFlowStreams?: Map<string, MediaStream>;
  }
}

const CHANNEL_NAME = 'worshipflow-studio-program';
const PROGRAM_KEY = 'worshipflow-studio-program-v1';

function registry() {
  window.__worshipFlowStreams ??= new Map<string, MediaStream>();
  return window.__worshipFlowStreams;
}

export function registerStream(stream: MediaStream) {
  const id = crypto.randomUUID();
  registry().set(id, stream);
  return id;
}

export function getStream(streamId?: string) {
  if (!streamId) return undefined;
  const own = registry().get(streamId);
  if (own) return own;
  try {
    return window.opener?.__worshipFlowStreams?.get(streamId) as MediaStream | undefined;
  } catch {
    return undefined;
  }
}

export function stopStream(streamId?: string) {
  const stream = streamId ? registry().get(streamId) : undefined;
  stream?.getTracks().forEach((track) => track.stop());
  if (streamId) registry().delete(streamId);
}

export function hydrateScene(scene: StudioScene | null, assets: StudioAsset[]) {
  if (!scene) return null;
  return {
    ...scene,
    sources: scene.sources.map((source) => ({
      ...source,
      url: source.assetId ? assets.find((asset) => asset.id === source.assetId)?.url : source.url,
    })),
  };
}

export function publishProgram(payload: ProgramPayload) {
  localStorage.setItem(PROGRAM_KEY, JSON.stringify(payload));
  const channel = new BroadcastChannel(CHANNEL_NAME);
  channel.postMessage(payload);
  channel.close();
}

export function readProgram(): ProgramPayload {
  try {
    const value = localStorage.getItem(PROGRAM_KEY);
    return value ? JSON.parse(value) as ProgramPayload : { scene: null, blackout: false, revision: 0 };
  } catch {
    return { scene: null, blackout: false, revision: 0 };
  }
}

export function subscribeProgram(callback: (payload: ProgramPayload) => void) {
  const channel = new BroadcastChannel(CHANNEL_NAME);
  channel.onmessage = (event: MessageEvent<ProgramPayload>) => callback(event.data);
  const storageListener = (event: StorageEvent) => {
    if (event.key === PROGRAM_KEY && event.newValue) callback(JSON.parse(event.newValue) as ProgramPayload);
  };
  window.addEventListener('storage', storageListener);
  return () => {
    channel.close();
    window.removeEventListener('storage', storageListener);
  };
}

export function outputUrl() {
  const url = new URL(window.location.href);
  url.search = '';
  url.searchParams.set('view', 'studio-output');
  return url.toString();
}

