import type { StudioAsset, StudioProject } from './types';

const DATABASE_NAME = 'worshipflow-studio';
const DATABASE_VERSION = 1;
const ASSET_STORE = 'assets';
const PROJECT_KEY = 'worshipflow-studio-project-v1';

interface StoredAsset {
  id: string;
  name: string;
  kind: StudioAsset['kind'];
  mime: string;
  size: number;
  blob: Blob;
}

function openDatabase() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(ASSET_STORE)) database.createObjectStore(ASSET_STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveAsset(file: File): Promise<StudioAsset> {
  const id = crypto.randomUUID();
  const kind = file.type.startsWith('image/') ? 'image'
    : file.type.startsWith('audio/') ? 'audio'
      : file.type === 'application/pdf' ? 'slides'
        : 'video';
  const stored: StoredAsset = { id, name: file.name, kind, mime: file.type, size: file.size, blob: file };
  const database = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(ASSET_STORE, 'readwrite');
    transaction.objectStore(ASSET_STORE).put(stored);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
  database.close();
  return { id, name: file.name, kind, mime: file.type, size: file.size, url: URL.createObjectURL(file) };
}

export async function loadAssets(): Promise<StudioAsset[]> {
  const database = await openDatabase();
  const records = await new Promise<StoredAsset[]>((resolve, reject) => {
    const request = database.transaction(ASSET_STORE, 'readonly').objectStore(ASSET_STORE).getAll();
    request.onsuccess = () => resolve(request.result as StoredAsset[]);
    request.onerror = () => reject(request.error);
  });
  database.close();
  return records.map((asset) => ({ ...asset, url: URL.createObjectURL(asset.blob) }));
}

export async function deleteAsset(id: string) {
  const database = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(ASSET_STORE, 'readwrite');
    transaction.objectStore(ASSET_STORE).delete(id);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
  database.close();
}

export function loadProject(): StudioProject | null {
  try {
    const value = localStorage.getItem(PROJECT_KEY);
    return value ? JSON.parse(value) as StudioProject : null;
  } catch {
    return null;
  }
}

export function saveProject(project: StudioProject) {
  localStorage.setItem(PROJECT_KEY, JSON.stringify(project));
}

