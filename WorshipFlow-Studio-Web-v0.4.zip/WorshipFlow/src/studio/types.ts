export type StudioSourceKind = 'video' | 'audio' | 'image' | 'youtube' | 'camera' | 'screen' | 'text' | 'lyrics' | 'slides';
export type SourceLayout = 'full' | 'pip-bottom-right' | 'pip-top-right' | 'center' | 'lower-third';
export type SceneTransition = 'cut' | 'fade' | 'dissolve' | 'slide';

export interface StudioAsset {
  id: string;
  name: string;
  kind: 'video' | 'audio' | 'image' | 'slides';
  mime: string;
  url: string;
  size: number;
}

export interface StudioSource {
  id: string;
  name: string;
  kind: StudioSourceKind;
  visible: boolean;
  muted: boolean;
  volume: number;
  layout: SourceLayout;
  assetId?: string;
  url?: string;
  youtubeId?: string;
  content?: string;
  streamId?: string;
  color?: string;
}

export interface StudioScene {
  id: string;
  name: string;
  transition: SceneTransition;
  duration: number;
  background: string;
  sources: StudioSource[];
}

export interface StudioProject {
  id: string;
  name: string;
  scenes: StudioScene[];
  previewSceneId: string;
  liveSceneId: string | null;
}

export interface ProgramPayload {
  scene: StudioScene | null;
  blackout: boolean;
  revision: number;
}

export type StudioView = 'studio' | 'media' | 'schedule' | 'broadcast';

