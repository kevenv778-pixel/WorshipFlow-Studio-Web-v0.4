export type ItemType = 'song' | 'video' | 'image' | 'bible' | 'notice';

export interface SongSegment {
  label: string;
  text: string;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  musicalKey: string;
  category: string;
  segments: SongSegment[];
}

export interface MediaItem {
  id: string;
  kind: 'video' | 'image';
  title: string;
  path: string;
  category: string;
  source: 'local' | 'youtube';
  videoId?: string;
}

export interface ServiceItem {
  id: string;
  type: ItemType;
  contentId: string | null;
  title: string;
  position: number;
  payload: Record<string, unknown>;
}

export interface Service {
  id: string;
  title: string;
  serviceDate: string;
  startTime: string;
  items: ServiceItem[];
}

export interface DisplayInfo {
  id: string;
  label: string;
  size: string;
  primary: boolean;
  selected: boolean;
}

export type PresentationMode = 'content' | 'blackout' | 'clear' | 'clock';

export interface PresentationState {
  mode: PresentationMode;
  type?: ItemType;
  title?: string;
  subtitle?: string;
  label?: string;
  text?: string;
  mediaUrl?: string;
  youtubeId?: string;
  paused?: boolean;
  theme?: 'aurora' | 'midnight' | 'warm';
}
